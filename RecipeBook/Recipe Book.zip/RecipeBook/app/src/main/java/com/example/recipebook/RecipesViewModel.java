package com.example.recipebook;


import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

public class RecipesViewModel extends AndroidViewModel {
    public RecipesViewModel(@NonNull Application application) {
        super(application);
    }
}
