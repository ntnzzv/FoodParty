package com.example.recipebook;

public class Constants {
    public static final String MAIN = "Class: MainActivity || Method: ";
    public static final String TAG="RecipesBook";
}
