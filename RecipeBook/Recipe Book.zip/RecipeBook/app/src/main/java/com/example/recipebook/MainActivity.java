package com.example.recipebook;


import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    private RecipesAdapter adapter;
    DatabaseReference DBReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setDBReference();
        setRecyclerViewAdapter();

    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }

    // Create a instance of the database, get its reference and set a listener
    private void setDBReference() {
        DBReference = FirebaseDatabase.getInstance().getReference().child("Recipes");
        DBReference.addChildEventListener(new RecipeEventListener());
    }

    private void setRecyclerViewAdapter() {
        RecyclerView rv = findViewById(R.id.rv_recipes_list);
        rv.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        FirebaseRecyclerOptions<Recipe> options = new FirebaseRecyclerOptions.Builder<Recipe>()
                .setQuery(DBReference, Recipe.class)
                .build();
        adapter = new RecipesAdapter(options);
        rv.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(@NonNull Menu menu) {
        Log.i(Constants.TAG, Constants.MAIN + "onCreateOptionsMenu()");
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Log.i(Constants.TAG, Constants.MAIN + "onOptionsItemSelected()");
        switch (item.getItemId()) {
            case R.id.searchItem:
                //handle search
                return true;
            case R.id.settingsItem:
                //handle settings
                return true;
            default:
                return false;
        }
    }

    private class RecipeEventListener implements ChildEventListener {

        @Override
        public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
            Recipe recipe = dataSnapshot.getValue(Recipe.class);
            recipe.setId(dataSnapshot.getKey());
            adapter.recipes.add(recipe);
        }

        @Override
        public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

        }

        @Override
        public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
            Recipe recipe = dataSnapshot.getValue(Recipe.class);
            recipe.setId(dataSnapshot.getKey());
            adapter.recipes.remove(recipe);
        }

        @Override
        public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {

        }
    }
}