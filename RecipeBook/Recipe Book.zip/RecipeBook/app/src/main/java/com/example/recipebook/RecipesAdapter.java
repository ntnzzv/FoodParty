package com.example.recipebook;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import java.util.ArrayList;
import java.util.List;

public class RecipesAdapter extends FirebaseRecyclerAdapter<Recipe, RecipesAdapter.RecipeViewHolder> {
    List<Recipe> recipes=new ArrayList<>();
    public RecipesAdapter(@NonNull FirebaseRecyclerOptions<Recipe> options) {
        super(options);

    }

    @NonNull
    @Override
    public RecipeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        // Create a new view, which defines the UI of the list item
        View view = inflater.inflate(R.layout.rv_item, parent, false);
        return new RecipeViewHolder(view);
    }



    @Override
    public int getItemCount() {
        return recipes.size();
    }

    @Override
    protected void onBindViewHolder(@NonNull RecipeViewHolder holder, int position, @NonNull Recipe model) {
        holder.setDetails(model);
    }


    public class RecipeViewHolder extends RecyclerView.ViewHolder {
        TextView name;
        TextView shortDescription;
        ImageView image;

        public RecipeViewHolder(View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.tv_name_item);
            shortDescription=itemView.findViewById(R.id.tv_description_item);
            image=itemView.findViewById(R.id.iv_image_item);
        }

        public void setDetails(Recipe recipe) {
            name.setText(recipe.getName());
            shortDescription.setText(recipe.getShortDescription());
            //handle with image
        }
    }

}
